package com.pizzalogin.VO;

import com.pizzalogin.entity.Login;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseTemplate {
    private Login login;
    private Order order;
    private Menu menu;
}
