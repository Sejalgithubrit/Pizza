package com.pizzalogin.controller;

import com.pizzalogin.VO.ResponseTemplate;
import com.pizzalogin.entity.Login;
import com.pizzalogin.service.LoginService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/login")
@Slf4j
public class LoginController {
    @Autowired
    private LoginService loginService;
    //Save the Login
    @PostMapping("/")
    public Login saveLogin(@RequestBody Login login){
        log.info("Inside save Login of LoginController");
        return loginService.saveLogin(login);
    }

    //Get the Order
    @GetMapping("{loginId}")
    public ResponseTemplate getLoginWithOrder(@PathVariable Long loginId){
        log.info("Inside save Login of LoginController");
        return loginService.getLoginWithOrder(loginId);
    }
    @GetMapping("menu/{menuId}")
    public ResponseTemplate getLoginWithMenu(@PathVariable Long menuId){
        log.info("Inside save Login of LoginController");
        return loginService.getLoginWithMenu(menuId);
    }


}
