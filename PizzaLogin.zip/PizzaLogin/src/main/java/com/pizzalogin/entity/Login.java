package com.pizzalogin.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="loginss_tb")
public class Login {
    //Variable declaration
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long loginId;
    private String username;
    private String password;
//    private String email;
   private Long orderId;
 private Long menuId;

}
