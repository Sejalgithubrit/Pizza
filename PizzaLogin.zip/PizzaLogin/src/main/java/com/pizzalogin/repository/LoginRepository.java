package com.pizzalogin.repository;

import com.pizzalogin.entity.Login;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoginRepository extends JpaRepository<Login,Long> {
    Login findByLoginId(Long loginId);

  //  Login findByname(String username);
}
