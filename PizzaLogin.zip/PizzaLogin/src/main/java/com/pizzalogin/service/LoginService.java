package com.pizzalogin.service;


import com.pizzalogin.VO.Menu;
import com.pizzalogin.VO.Order;
import com.pizzalogin.VO.ResponseTemplate;
import com.pizzalogin.entity.Login;
import com.pizzalogin.repository.LoginRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Slf4j
public class LoginService {
    @Autowired
    private LoginRepository loginRepository;
    @Autowired
    private RestTemplate restTemplate;

    public Login saveLogin(Login login) {
        log.info("Inside save Login of LoginController");
        return loginRepository.save(login);
    }
//Long loginId
    public ResponseTemplate getLoginWithOrder(Long loginId) {
        log.info("Inside save Login of LoginController");
        ResponseTemplate vo=new ResponseTemplate();
             //   Login logins=loginRepository.findByname(username);

               Login login=loginRepository.findByLoginId(loginId);


        Order order=restTemplate.getForObject("http://localhost:9099/order/"
                +login.getOrderId(),Order.class);
//       Menu menu=restTemplate.getForObject("http://localhost:9094/menu/"+login.getMenuId(), Menu.class);
        vo.setLogin(login);
        vo.setOrder(order);
       // vo.setMenu(menu);
        return vo;

    }



    public ResponseTemplate getLoginWithMenu(Long menuId) {
        ResponseTemplate vo=new ResponseTemplate();
      //  Login login=loginRepository.findByLoginId(menuId);
        Menu menu=restTemplate.getForObject("http://localhost:9094/menu/"+menuId, Menu.class);
      //  vo.setLogin(login);
        vo.setMenu(menu);

        return vo;
    }
}
