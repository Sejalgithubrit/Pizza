package com.example.pizzamenu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PizzaMenuApplication {

    public static void main(String[] args) {
        SpringApplication.run(PizzaMenuApplication.class, args);
    }

}
