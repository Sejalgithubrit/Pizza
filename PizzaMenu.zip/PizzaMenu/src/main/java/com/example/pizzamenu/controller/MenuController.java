package com.example.pizzamenu.controller;

import com.example.pizzamenu.entiti.Menu;
import com.example.pizzamenu.service.MenuService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/menu")
@Slf4j
public class MenuController {
    @Autowired
    private MenuService orderService;
    @PostMapping("/")
    public Menu saveOrder(@RequestBody Menu order){
        log.info("Order save add into order");
        return orderService.saveOrder(order);
    }


    @GetMapping("/{id}")
    public Menu findOrderById(@PathVariable("id") Long menuId){
        log.info("Order by id add into order");
        return orderService.findOrderById(menuId);
    }
}
