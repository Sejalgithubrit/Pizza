package com.example.pizzamenu.service;

import com.example.pizzamenu.entiti.Menu;
import com.example.pizzamenu.repository.MenuRepository;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class MenuService {

    @Autowired
    private MenuRepository orderRepository;

    public Menu saveOrder(Menu order) {
        log.info("Order save to order");
        return orderRepository.save(order);
    }




    public Menu findOrderById(Long menuId) {
        log.info("Order saveby id to order");
        return orderRepository.findBymenuId(menuId);
    }
}
