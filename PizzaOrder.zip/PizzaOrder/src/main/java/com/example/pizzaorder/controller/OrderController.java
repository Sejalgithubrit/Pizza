package com.example.pizzaorder.controller;

import com.example.pizzaorder.entity.Order;
import com.example.pizzaorder.service.OrderService;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.weaver.ast.Or;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/order")
@Slf4j
public class OrderController {
    @Autowired
    private OrderService orderService;
    // add all Order
    @PostMapping("/")
    public Order saveOrder(@RequestBody Order order){
        log.info("Order save add into order");
        return orderService.saveOrder(order);
    }
    // Get all Order
    @GetMapping("/")
    public List<Order> findAllOrder(){
        log.info("Order  all add into order");
        return orderService.findAll();
    }
    //Get By id
    @GetMapping("/{id}")
    public Order findOrderById(@PathVariable("id") Long orderId){
        log.info("Order by id add into order");
        return orderService.findOrderById(orderId);
    }
}
