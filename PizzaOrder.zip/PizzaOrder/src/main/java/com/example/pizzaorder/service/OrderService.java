package com.example.pizzaorder.service;

import com.example.pizzaorder.entity.Order;
import com.example.pizzaorder.repository.OrderRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;
//save all
    public Order saveOrder(Order order) {
        log.info("Order save to order");
        return orderRepository.save(order);
    }
//get by id
    public Order findOrderById(Long orderId) {
        log.info("Order saveby id to order");
        return orderRepository.findByOrderId(orderId);
    }

//get all order
    public List<Order> findAll() {
        return orderRepository.findAll();
    }
}
