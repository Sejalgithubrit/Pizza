package com.example.pizzaorder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzaOrderApplicationTests {

    @Test
    void contextLoads() {
    }

}
